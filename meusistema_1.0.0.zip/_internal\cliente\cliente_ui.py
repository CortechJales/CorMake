from PyQt5.QtWidgets import QWidget, QDialog,QFormLayout, QMessageBox, QCheckBox,QRadioButton, QButtonGroup, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget, QComboBox,QTableWidgetItem, QHeaderView, QAction, QToolBar, QApplication
from PyQt5.QtCore import Qt,QRegExp
from cliente.cliente_controller import ClienteController
from categoria.categoria_controller import CategoriaController
from PyQt5.QtGui import QIcon
import re
import requests
import os


class ClienteUI(QWidget):
    def __init__(self,user_type):
        super().__init__()
        self.controller = ClienteController()      
        self.user_type= user_type
        self.initUI()
        
        print(f"tipo que chegou na cliente: {user_type}")

    def initUI(self):
        # Layout principal
        layout = QVBoxLayout()

        # Layout do filtro
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Filtrar por nome:"))
        self.filter_input = QLineEdit()
        self.filter_input.textChanged.connect(self.filter_table)
        filter_layout.addWidget(self.filter_input)

        # Estilo para os botões de filtro
        filter_button_style = """
            QPushButton {
                background-color: #f5026d;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 5px 10px;
                margin-left: 10px;
            }
            QPushButton:hover {
                background-color: #ff93c1;
            }
        """

        if self.user_type == 'adm':
           
            self.btn_active = QPushButton("Ativos")
            self.btn_active.setStyleSheet(filter_button_style)
            self.btn_active.clicked.connect(self.filter_active)
            filter_layout.addWidget(self.btn_active)

            self.btn_inactive = QPushButton("Inativos")
            self.btn_inactive.setStyleSheet(filter_button_style)
            self.btn_inactive.clicked.connect(self.filter_inactive)
            filter_layout.addWidget(self.btn_inactive)

        layout.addLayout(filter_layout)

        # Tabela de clientes
        self.client_table = QTableWidget()
        self.client_table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border: 2px solid #f5026d;
                padding: 5px;
                border-radius: 5px;
                color: #333;
            }
            
            QHeaderView::section {
                background-color: #f5026d;
                color: white;
                padding: 5px;
                border: 1px solid #ddd;
            }
            QTableWidget::item {
                border: none;
                padding: 5px;
            }
            QTableWidget::item:selected {
                background-color: #ff93c1;
                color: black;
            }
        """)
        self.client_table.setColumnCount(7)
        self.client_table.setHorizontalHeaderLabels(['Código', 'Nome','Telefone', 'CEP', 'Endereço','Número', 'Ativo'])
        self.client_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.client_table)

        # Barra de ferramentas com botões de ação
        toolbar = QToolBar("Barra de Ferramentas")
        toolbar.setStyleSheet("""
            QToolBar {
                background-color: #ecf0f1;
                padding: 10px;
                border-radius: 10px;
            }
            QToolButton {
                background-color: #f5026d;
                color: white;
                padding: 5px 10px;
                border: none;
                border-radius: 5px;
                margin-right: 5px;
            }
            QToolButton:hover {
                background-color: #ff93c1;
            }
        """)
        layout.addWidget(toolbar)
        
        if self.user_type == 'adm':
            # Botões de ação
            action_add = QAction("Adicionar", self)
            action_edit = QAction("Editar", self)
            action_delete = QAction("Excluir", self)
            action_inactive = QAction("Inativar", self)
            action_ative = QAction("Reativar", self)

            toolbar.addAction(action_add)
            toolbar.addAction(action_edit)
            toolbar.addAction(action_delete)
            toolbar.addAction(action_inactive)        
            toolbar.addAction(action_ative)

        # Configurar conexões de sinais e slots para os botões
            action_add.triggered.connect(self.show_add_cliente_dialog)
            action_edit.triggered.connect(self.show_edit_cliente_dialog)
            action_delete.triggered.connect(self.delete_cliente)
            action_inactive.triggered.connect(self.inactive_cliente)
            action_ative.triggered.connect(self.ative_cliente)
        if self.user_type == 'usr':
            # Botões de ação
            action_add = QAction("Adicionar", self)
            action_edit = QAction("Editar", self)
            action_inactive = QAction("Inativar", self)

            toolbar.addAction(action_add)
            toolbar.addAction(action_edit)
            toolbar.addAction(action_inactive)   

        # Configurar conexões de sinais e slots para os botões
            action_add.triggered.connect(self.show_add_cliente_dialog)
            action_edit.triggered.connect(self.show_edit_cliente_dialog)
            action_inactive.triggered.connect(self.inactive_cliente)

        self.setLayout(layout)
        
        self.controller.create_table()       
        self.filter_active()

        # Adicionar evento de clique duplo na tabela de clientes
        self.client_table.doubleClicked.connect(self.show_cliente_details)
        

    def filter_table(self):
        filter_text = self.filter_input.text().lower()
        for row in range(self.client_table.rowCount()):
            match = False
            for col in range(self.client_table.columnCount()):
                item = self.client_table.item(row, col)
                if item is not None and item.text().lower().find(filter_text) != -1:
                    match = True
                    break
            self.client_table.setRowHidden(row, not match)

   
    def filter_active(self):
        clientes = self.controller.ListarCliente(True)
        self.client_table.setRowCount(0)
    
        for row_number, cliente in enumerate(clientes):
            self.client_table.insertRow(row_number)
        
            for column_number, data in enumerate(cliente):
                item = QTableWidgetItem(str(data))
            
                if column_number == 6:  # Coluna 'Ativo'
                    checkbox = QCheckBox()
                    checkbox.setChecked(bool(data))
                    checkbox.setEnabled(False)
                    cell_widget = QWidget()
                    layout = QHBoxLayout(cell_widget)
                    layout.addWidget(checkbox)
                    layout.setAlignment(Qt.AlignCenter)
                    layout.setContentsMargins(0, 0, 0, 0)
                    self.client_table.setCellWidget(row_number, column_number, cell_widget)
                else:
                    self.client_table.setItem(row_number, column_number, item)

    def filter_inactive(self):
        clientes = self.controller.ListarCliente(False)
        self.client_table.setRowCount(0)
    
        for row_number, cliente in enumerate(clientes):
            self.client_table.insertRow(row_number)
        
            for column_number, data in enumerate(cliente):
                item = QTableWidgetItem(str(data))
            
                if column_number == 6:  # Coluna 'Ativo'
                    checkbox = QCheckBox()
                    checkbox.setChecked(bool(data))
                    checkbox.setEnabled(False)
                    cell_widget = QWidget()
                    layout = QHBoxLayout(cell_widget)
                    layout.addWidget(checkbox)
                    layout.setAlignment(Qt.AlignCenter)
                    layout.setContentsMargins(0, 0, 0, 0)
                    self.client_table.setCellWidget(row_number, column_number, cell_widget)
                else:
                    self.client_table.setItem(row_number, column_number, item)

    def add_cliente(self, nome,telefone,cep, endereco, numero):
        self.controller.CadastrarCliente( nome,telefone,cep, endereco, numero)
        self.filter_active()  # Atualizar a tabela após adicionar clientes

    def edit_cliente(self, nome,telefone,cep, endereco, numero, id):
        self.controller.EditarCliente( nome,telefone,cep, endereco, numero,id)
        self.filter_active()  # Atualizar a tabela após adicionar clientes


    def delete_cliente(self,id):
      
        selected_row = self.client_table.currentRow()
        if selected_row != -1:
            id = self.client_table.item(selected_row, 0).text()
            resposta = QMessageBox.question(self, "Confirmação", f"Tem certeza que deseja excluir o cliente ID {id}?", QMessageBox.Yes | QMessageBox.No)
            if resposta == QMessageBox.Yes:
                self.controller.DeletarCliente(id)
                self.filter_active()
        else:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente para excluir.")

    def inactive_cliente(self):
        selected_row = self.client_table.currentRow()
        if selected_row != -1:
            id = self.client_table.item(selected_row, 0).text()
            resposta = QMessageBox.question(self, "Confirmação", f"Tem certeza que deseja inativar o cliente código {id}?", QMessageBox.Yes | QMessageBox.No)
            if resposta == QMessageBox.Yes:
                resultado = self.controller.ValidarCliente(id)
                if resultado:
                    estado_cliente = resultado[0][0]  # Obtém o estado do cliente da consulta
                    if estado_cliente == 1:  # Verifica se o cliente está ativo
                        self.controller.AtivarInativarCliente(False,id)
                        self.filter_active()
                    else:
                        QMessageBox.warning(self, "Aviso", "Cliente já está inativo.")
                else:
                    QMessageBox.warning(self, "Aviso", "Cliente não encontrado.")
        else:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente para inativar.")
 
    def ative_cliente(self):
        selected_row = self.client_table.currentRow()
        if selected_row != -1:
            id = self.client_table.item(selected_row, 0).text()
            resposta = QMessageBox.question(self, "Confirmação", f"Tem certeza que deseja reativar o cliente código {id}?", QMessageBox.Yes | QMessageBox.No)
            if resposta == QMessageBox.Yes:
                resultado = self.controller.ValidarCliente(id)
                if resultado:
                    estado_cliente = resultado[0][0]  # Obtém o estado do cliente da consulta
                    if estado_cliente == 0:  # Verifica se o cliente está inativo
                        self.controller.AtivarInativarCliente(True,id)
                        self.filter_active()
                    else:
                        QMessageBox.warning(self, "Aviso", "Cliente já está Ativo.")
                else:
                    QMessageBox.warning(self, "Aviso", "Cliente não encontrado.")
        else:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente para Ativar.")   

    def show_add_cliente_dialog(self):
        dialog = AdicionarEditarClienteDialog()
        if dialog.exec_():
            nome = dialog.nome.text()
            telefone = dialog.telefone.text()
            cep = dialog.cep.text()
            endereco = dialog.endereco.text()
            numero = dialog.numero.text()
            
          
         
            self.add_cliente(nome,telefone,cep, endereco, numero)
   
    def show_edit_cliente_dialog(self):
        selected_row = self.client_table.currentRow()
        if selected_row != -1:
            id = self.client_table.item(selected_row, 0).text()
            nome = self.client_table.item(selected_row, 1).text()
            telefone = self.client_table.item(selected_row, 2).text()
            cep = self.client_table.item(selected_row, 3).text()
            endereco = self.client_table.item(selected_row, 4).text()
            numero = self.client_table.item(selected_row, 5).text()
           
            dialog = AdicionarEditarClienteDialog(nome,telefone,cep, endereco, numero)
            if dialog.exec_():
                novo_nome = dialog.nome.text()
                novo_telefone = dialog.telefone.text()
                novo_cep = dialog.cep.text()
                novo_endereco = dialog.endereco.text()
                novo_numero = dialog.numero.text()
                
               
                self.edit_cliente(novo_nome, novo_telefone,novo_cep, novo_endereco,novo_numero,id)
        else:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente para editar.")

    def show_cliente_details(self):
        selected_row = self.client_table.currentRow()
        if selected_row != -1:
           
            cliente_info = {
            'Código': self.client_table.item(selected_row, 0).text(),   
            'Nome': self.client_table.item(selected_row, 1).text(),
            'Telefone': self.client_table.item(selected_row, 2).text(),
            'Cep': self.client_table.item(selected_row, 3).text(),
            'endereco': self.client_table.item(selected_row, 4).text(),
            'Número': self.client_table.item(selected_row, 5).text(),
            
        }
            cliente_id = self.client_table.item(selected_row, 0).text()  

            dialog = DetalhesClienteDialog(cliente_info, self.user_type)
        
        # Definindo o tamanho mínimo e máximo da janela
            dialog.setMinimumSize(700, 500)  # Defina o tamanho mínimo desejado
            dialog.setMaximumSize(900, 700)  # Defina o tamanho máximo desejado

            dialog.exec_()

        else:
            QMessageBox.warning(self, "Aviso", "Selecione um cliente para ver os detalhes.")
    



class AdicionarEditarClienteDialog(QDialog):
    def __init__(self, nome="", telefone="", cep="", endereco="", numero=""):
        super().__init__()
        self.setWindowTitle("Adicionar Cliente")
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))
        # Subindo um nível para acessar a pasta img
        pasta_img = os.path.join(diretorio_atual, '..', 'img')
        # Path para a imagem específica
        caminho_imagem = os.path.join(pasta_img, 'cormake.png')
        self.setWindowIcon(QIcon(caminho_imagem)) # Adicione o ícone desejado

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)  # Adicione margens para espaçamento

        form_layout = QFormLayout()

        self.nome = QLineEdit(nome)
        self.telefone = QLineEdit(telefone)
        self.cep = QLineEdit(cep)
        self.endereco = QLineEdit(endereco)
        self.numero = QLineEdit(numero)
       

        # Estilo CSS para os campos de entrada
        style_sheet = """
            QLineEdit, QComboBox {
                border: 2px solid #ff93c1;
                border-radius: 10px;
                padding: 8px;
                font-size: 14px;
            }
            QLineEdit:focus, QComboBox:focus {
                border-color: #f5026d;
            }
        """
        self.nome.setStyleSheet(style_sheet)
        self.cep.setStyleSheet(style_sheet)
        self.endereco.setStyleSheet(style_sheet)
        self.numero.setStyleSheet(style_sheet)
        self.telefone.setStyleSheet(style_sheet)

        # Adicionando siglas dos estados ao QComboBox
        

        form_layout.addRow(QLabel("Nome:"), self.nome)
        
        self.celular1 = QRadioButton("Celular")
        self.fixo1 = QRadioButton("Fixo")
        self.nao_informar_tel1 = QRadioButton("Não informar")
        self.celular1.setChecked(True)  # Definindo Pessoa Física como padrão
        self.tipo_celular = QButtonGroup()
        self.tipo_celular.addButton(self.celular1)
        self.tipo_celular.addButton(self.fixo1)
        self.tipo_celular.addButton(self.nao_informar_tel1)
        self.tipo_celular.buttonClicked.connect(self.update_telefone_mask1)
        tipo_celular_layout = QHBoxLayout()
        tipo_celular_layout.addWidget(self.celular1)
        tipo_celular_layout.addWidget(self.fixo1);        
        tipo_celular_layout.addWidget(self.nao_informar_tel1)
        
        form_layout.addRow(QLabel("Tipo de telefone:"), tipo_celular_layout)
        form_layout.addRow(QLabel("Telefone 1:"), self.telefone)

        form_layout.addRow(QLabel("CEP:"), self.cep)
        form_layout.addRow(QLabel("Endereço:"), self.endereco)
        form_layout.addRow(QLabel("Número:"), self.numero)

        layout.addLayout(form_layout)

        # Adicione um layout de botão para alinhar os botões horizontalmente
        button_layout = QHBoxLayout()
        btn_salvar = QPushButton("Salvar")
        btn_cancelar = QPushButton("Cancelar")
        btn_salvar.setStyleSheet("background-color: #f5026d; color: white; border-radius: 10px; padding: 10px;")
        btn_cancelar.setStyleSheet("background-color: #be0d32; color: white; border-radius: 10px; padding: 10px;")
        btn_salvar.clicked.connect(self.on_save)
        btn_cancelar.clicked.connect(self.reject)
        button_layout.addWidget(btn_salvar)
        button_layout.addWidget(btn_cancelar)

        layout.addLayout(button_layout)

        self.setLayout(layout)

        # Conectar sinal de edição de CEP ao método de preenchimento automático
        self.cep.textChanged.connect(self.auto_fill_address)

        # Aplicar máscara inicial ao CPF/CNPJ e telefone
        self.update_telefone_mask1()

        
        self.cep.setInputMask('00000-000;_')

       
    def on_save(self):
        if not self.validate_fields():
            return

        self.accept()

    def validate_fields(self):
        # Verificar se todos os campos estão preenchidos
        if not all([self.nome.text()]):
            QMessageBox.warning(self, "Erro", "O nome deve estar preenchido.")
            return False        

        return True
    def auto_fill_address(self):
        cep = self.cep.text().replace("-", "")
        if len(cep) == 8:
            try:
                response = requests.get(f"https://viacep.com.br/ws/{cep}/json/")
                data = response.json()
                if "erro" not in data:
                    self.endereco.setText(data.get("logradouro", ""))
            except Exception as e:
                print(f"Erro ao buscar endereço: {e}")

    def update_telefone_mask1(self):
        if self.celular1.isChecked():
            self.telefone.setInputMask('(00)00000-0000;_')

        else:
            if self.fixo1.isChecked():
                self.telefone.setInputMask('(00)0000-0000;_')
            else:
                self.telefone.setInputMask('')  
                 
    
class DetalhesClienteDialog(QDialog):
    def __init__(self, cliente_info, equipamentos, user_type):
        super().__init__()

        self.cliente_info = cliente_info
        self.equipamentos = equipamentos
        self.user_type = user_type  
        
        self.controller_marca = CategoriaController()
        self.setWindowTitle("Detalhes do Cliente")
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))
        # Subindo um nível para acessar a pasta img
        pasta_img = os.path.join(diretorio_atual, '..', 'img')
        # Path para a imagem específica
        caminho_imagem = os.path.join(pasta_img, 'megamotores.png')
        self.setWindowIcon(QIcon(caminho_imagem))

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)

        form_layout = QFormLayout()

        self.campos_cliente = {}

        for key, value in cliente_info.items():
            label = QLabel(key.capitalize() + ":")
            field = QLineEdit(str(value))
            field.setReadOnly(True)
            field.setStyleSheet("background-color: white; border: 2px solid #3498db; padding: 5px; border-radius: 5px; color: #333;")
            self.campos_cliente[key] = field
            form_layout.addRow(label, field)

        layout.addLayout(form_layout)
    
if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    ui = ClienteUI()  
    ui.show()
    sys.exit(app.exec_())
