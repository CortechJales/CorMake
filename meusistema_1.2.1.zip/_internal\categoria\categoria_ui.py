from PyQt5.QtWidgets import QWidget, QDialog, QDoubleSpinBox, QMessageBox,QCheckBox,QFormLayout, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QAction, QToolBar, QApplication
from PyQt5.QtCore import Qt
from categoria.categoria_controller import CategoriaController
from PyQt5.QtGui import QIcon,QDoubleValidator
import os

class CategoriaUI(QWidget):
    def __init__(self,user_type):
        super().__init__()
        self.controller = CategoriaController()
        self.user_type= user_type
        self.initUI()
        

    def initUI(self):
        # Layout principal
        layout = QVBoxLayout()
 # Layout do filtro
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Filtrar por Nome / Código:"))
        self.filter_input = QLineEdit()
        self.filter_input.textChanged.connect(self.filter_table)
        filter_layout.addWidget(self.filter_input)

        # Estilo para os botões de filtro
        filter_button_style = """
             QPushButton {
                background-color: #f5026d;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 5px 10px;
                margin-left: 10px;
            }
            QPushButton:hover {
                background-color: #ff93c1;
            }
        """

        if self.user_type == 'adm':
            self.btn_active = QPushButton("Ativos")
            self.btn_active.setStyleSheet(filter_button_style)
            self.btn_active.clicked.connect(self.filter_active)
            filter_layout.addWidget(self.btn_active)

            self.btn_inactive = QPushButton("Inativos")
            self.btn_inactive.setStyleSheet(filter_button_style)
            self.btn_inactive.clicked.connect(self.filter_inactive)
            filter_layout.addWidget(self.btn_inactive)

        layout.addLayout(filter_layout)

        # Tabela de clientes
        self.categoria_table = QTableWidget()
        self.categoria_table.setStyleSheet("""
          QTableWidget {
                background-color: white;
                border: 2px solid #f5026d;
                padding: 5px;
                border-radius: 5px;
                color: #333;
            }
            
            QHeaderView::section {
                background-color: #f5026d;
                color: white;
                padding: 5px;
                border: 1px solid #ddd;
            }
            QTableWidget::item {
                border: none;
                padding: 5px;
            }
            QTableWidget::item:selected {
                background-color: #ff93c1;
                color: black;
            }
        """)
        self.categoria_table.setColumnCount(3)
        self.categoria_table.setHorizontalHeaderLabels(['Código', 'Descrição', 'Ativo'])
        self.categoria_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.categoria_table)

        # Barra de ferramentas com botões de ação
        toolbar = QToolBar("Barra de Ferramentas")
        toolbar.setStyleSheet("""
             QToolBar {
                background-color: #ecf0f1;
                padding: 10px;
                border-radius: 10px;
            }
            QToolButton {
                background-color: #f5026d;
                color: white;
                padding: 5px 10px;
                border: none;
                border-radius: 5px;
                margin-right: 5px;
            }
            QToolButton:hover {
                background-color: #ff93c1;
            }
        """)
        layout.addWidget(toolbar)
        
        if self.user_type == 'adm':
            # Botões de ação
            action_add = QAction("Adicionar", self)
            action_edit = QAction("Editar", self)
            action_delete = QAction("Excluir", self)
            action_inactive = QAction("Inativar", self)
            action_ative = QAction("Reativar", self)

            toolbar.addAction(action_add)
            toolbar.addAction(action_edit)
            toolbar.addAction(action_delete)
            toolbar.addAction(action_inactive)        
            toolbar.addAction(action_ative)

        # Configurar conexões de sinais e slots para os botões
            action_add.triggered.connect(self.show_add_categoria_dialog)
            action_edit.triggered.connect(self.show_edit_categoria_dialog)
            action_delete.triggered.connect(self.delete_categoria)
            action_inactive.triggered.connect(self.inactive_categoria)
            action_ative.triggered.connect(self.ative_categoria)
        if self.user_type == 'usr':
            # Botões de ação
            action_add = QAction("Adicionar", self)
            action_edit = QAction("Editar", self)
            action_inactive = QAction("Inativar", self)

            toolbar.addAction(action_add)
            toolbar.addAction(action_edit)
            toolbar.addAction(action_inactive)  

        # Configurar conexões de sinais e slots para os botões
            action_add.triggered.connect(self.show_add_categoria_dialog)
            action_edit.triggered.connect(self.show_edit_categoria_dialog)
            action_inactive.triggered.connect(self.inactive_categoria)

        self.controller.create_table()
        self.setLayout(layout)
        self.filter_active()

    def filter_table(self):
        filter_text = self.filter_input.text().lower()
        for row in range(self.categoria_table.rowCount()):
            match = False
            for col in range(self.categoria_table.columnCount()):
                item = self.categoria_table.item(row, col)
                if item is not None and item.text().lower().find(filter_text) != -1:
                    match = True
                    break
            self.categoria_table.setRowHidden(row, not match)

    
    def filter_active(self):
        marcas = self.controller.ListarCategoria(True)
        self.categoria_table.setRowCount(0)
    
        for row_number, marca in enumerate(marcas):
            self.categoria_table.insertRow(row_number)
        
            for column_number, data in enumerate(marca):
                item = QTableWidgetItem(str(data))
            
                if column_number == 2:  # Coluna 'Ativo'
                    checkbox = QCheckBox()
                    checkbox.setChecked(bool(data))
                    checkbox.setEnabled(False)
                    cell_widget = QWidget()
                    layout = QHBoxLayout(cell_widget)
                    layout.addWidget(checkbox)
                    layout.setAlignment(Qt.AlignCenter)
                    layout.setContentsMargins(0, 0, 0, 0)
                    self.categoria_table.setCellWidget(row_number, column_number, cell_widget)
                else:
                    self.categoria_table.setItem(row_number, column_number, item)

    def filter_inactive(self):
        marcas = self.controller.ListarCategoria(False)
        self.categoria_table.setRowCount(0)
    
        for row_number, marca in enumerate(marcas):
            self.categoria_table.insertRow(row_number)
        
            for column_number, data in enumerate(marca):
                item = QTableWidgetItem(str(data))
            
                if column_number == 2:  # Coluna 'Ativo'
                    checkbox = QCheckBox()
                    checkbox.setChecked(bool(data))
                    checkbox.setEnabled(False)
                    cell_widget = QWidget()
                    layout = QHBoxLayout(cell_widget)
                    layout.addWidget(checkbox)
                    layout.setAlignment(Qt.AlignCenter)
                    layout.setContentsMargins(0, 0, 0, 0)
                    self.categoria_table.setCellWidget(row_number, column_number, cell_widget)
                else:
                    self.categoria_table.setItem(row_number, column_number, item)

    def add_categoria(self, descricao):
        self.controller.CadastrarCategoria(descricao)
        self.filter_active()  # Atualizar a tabela após adicionar clientes

    def edit_categoria(self, descricao, id):
        self.controller.EditarCategoria(descricao, id)
        self.filter_active()  # Atualizar a tabela após adicionar clientes


    def delete_categoria(self,id):
      
        selected_row = self.categoria_table.currentRow()
        if selected_row != -1:
            id = self.categoria_table.item(selected_row, 0).text()
            resposta = QMessageBox.question(self, "Confirmação", f"Tem certeza que deseja excluir a Categoria código {id}?", QMessageBox.Yes | QMessageBox.No)
            if resposta == QMessageBox.Yes:
                self.controller.DeletarCategoria(id)
                self.filter_active()
        else:
            QMessageBox.warning(self, "Aviso", "Selecione uma Categoria para excluir.")

    def inactive_categoria(self):
        selected_row = self.categoria_table.currentRow()
        if selected_row != -1:
            id = self.categoria_table.item(selected_row, 0).text()
            resposta = QMessageBox.question(self, "Confirmação", f"Tem certeza que deseja inativar a categoria código {id}?", QMessageBox.Yes | QMessageBox.No)
            if resposta == QMessageBox.Yes:
                resultado = self.controller.ValidarCategoria(id)
                if resultado:
                    estado_produto = resultado[0][0]  # Obtém o estado do cliente da consulta
                    if estado_produto == 1:  # Verifica se o cliente está ativo
                        self.controller.AtivarInativarCategoria(False,id)
                        self.filter_active()
                    else:
                        QMessageBox.warning(self, "Aviso", "categoria já está inativo.")
                else:
                    QMessageBox.warning(self, "Aviso", "categoria não encontrado.")
        else:
            QMessageBox.warning(self, "Aviso", "Selecione uma categoria para inativar.")
 
    def ative_categoria(self):
        selected_row = self.categoria_table.currentRow()
        if selected_row != -1:
            id = self.categoria_table.item(selected_row, 0).text()
            resposta = QMessageBox.question(self, "Confirmação", f"Tem certeza que deseja reativar a categoria código {id}?", QMessageBox.Yes | QMessageBox.No)
            if resposta == QMessageBox.Yes:
                resultado = self.controller.ValidarCategoria(id)
                if resultado:
                    estado_cliente = resultado[0][0]  # Obtém o estado do cliente da consulta
                    if estado_cliente == 0:  # Verifica se o cliente está inativo
                        self.controller.AtivarInativarCategoria(True,id)
                        self.filter_active()
                    else:
                        QMessageBox.warning(self, "Aviso", "categoria já está Ativo.")
                else:
                    QMessageBox.warning(self, "Aviso", "categoria não encontrado.")
        else:
            QMessageBox.warning(self, "Aviso", "Selecione um categoria para Ativar.")   

    def show_add_categoria_dialog(self):
        dialog = AdicionarEditarCategoriaDialog()
        if dialog.exec_():
            descricao = dialog.descricao.text()
            self.add_categoria(descricao)
   
    def show_edit_categoria_dialog(self):
        selected_row = self.categoria_table.currentRow()
        if selected_row != -1:
            id = self.categoria_table.item(selected_row, 0).text()
            descricao = self.categoria_table.item(selected_row, 1).text()
            dialog = AdicionarEditarCategoriaDialog(descricao)
            if dialog.exec_():
                novo_nome = dialog.descricao.text()
               
                
                self.edit_categoria(novo_nome, id)
        else:
            QMessageBox.warning(self, "Aviso", "Selecione uma categoria para editar.")


class AdicionarEditarCategoriaDialog(QDialog):
    def __init__(self, descricao=""):
        super().__init__()
        self.setWindowTitle("Adicionar Categoria")
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))
        # Subindo um nível para acessar a pasta img
        pasta_img = os.path.join(diretorio_atual, '..', 'img')
        # Path para a imagem específica
        caminho_imagem = os.path.join(pasta_img, 'megamotores.png')
        self.setWindowIcon(QIcon(caminho_imagem)) # Adicione o ícone desejado
        self.controller = CategoriaController()

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20) 

        form_layout = QFormLayout()
        
        self.descricao = QLineEdit(descricao)

        # Estilo CSS para os campos de entrada
        style_sheet = """
            QLineEdit, QComboBox, QDoubleSpinBox {
                border: 2px solid #ff93c1;
                border-radius: 10px;
                padding: 8px;
                font-size: 14px;
            }
            QLineEdit:focus, QComboBox:focus, QDoubleSpinBox:focus{
                border-color: #f5026d;
            }
        """
        self.descricao.setStyleSheet(style_sheet)

        form_layout.addRow(QLabel("Descrição:"), self.descricao)
       
        layout.addLayout(form_layout)
        
       # Adicione um layout de botão para alinhar os botões horizontalmente
        button_layout = QHBoxLayout()
        btn_salvar = QPushButton("Salvar")
        btn_cancelar = QPushButton("Cancelar")
        btn_salvar.setStyleSheet("background-color: #f5026d; color: white; border-radius: 10px; padding: 10px;")
        btn_cancelar.setStyleSheet("background-color: #be0d32; color: white; border-radius: 10px; padding: 10px;")
        btn_salvar.clicked.connect(self.on_save)
        btn_cancelar.clicked.connect(self.reject)
        button_layout.addWidget(btn_salvar)
        button_layout.addWidget(btn_cancelar)

        layout.addLayout(button_layout)

        self.setLayout(layout)
    
    def on_save(self):
        if not self.validate_fields():
            return

        self.accept()

    def validate_fields(self):
        # Verificar se todos os campos estão preenchidos
        if not all([self.descricao.text()]):
            QMessageBox.warning(self, "Erro", "O campo deve ser preenchido.")
            return False
        
        return True
   
if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    ui = CategoriaUI()  
    ui.show()
    sys.exit(app.exec_())
