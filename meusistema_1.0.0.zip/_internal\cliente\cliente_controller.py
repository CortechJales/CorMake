from database.database import Database
class ClienteController:
    def __init__(self):
        self.db = Database()    
    
    def create_table(self):
        sql = '''
        CREATE TABLE IF NOT EXISTS cliente (
            id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
            nome_cliente TEXT NOT NULL,
            telefone_cliente TEXT,
            cep_cliente TEXT,
            rua_cliente TEXT,
            numero_cliente TEXT,
            ativo_cliente BOOLEAN DEFAULT 1
        )
        '''
        self.db.create_table(sql)

    def ListarCliente(self,tipo):
        query = '''
        SELECT id_cliente, nome_cliente, telefone_cliente, cep_cliente, rua_cliente, 
            numero_cliente, ativo_cliente 
        FROM cliente 
        WHERE ativo_cliente = ?;
        '''
        data = (tipo,)
        return self.db.execute_query(query, data)
    
    def BuscarCliente(self, id_cliente):
        query = '''
        SELECT id_cliente, nome_cliente, telefone_cliente, cep_cliente, rua_cliente, 
            numero_cliente, ativo_cliente 
        FROM cliente 
        WHERE id_cliente = ?;
        '''
        data = (id_cliente,)
        return self.db.execute_query(query, data)

    
    def CadastrarCliente(self, nome_cliente, telefone_cliente, cep_cliente, rua_cliente, numero_cliente):
        query = '''
        INSERT INTO cliente (nome_cliente, telefone_cliente, cep_cliente, rua_cliente, 
                            numero_cliente, ativo_cliente) 
        VALUES (?, ?, ?, ?, ?, 1)
        '''
        data = (nome_cliente, telefone_cliente, cep_cliente, rua_cliente, numero_cliente)
        self.db.execute_query_no_return(query, data)

    
    def EditarCliente(self, nome_cliente, telefone_cliente, cep_cliente, rua_cliente, numero_cliente, id_cliente):
        query = '''
        UPDATE cliente 
        SET nome_cliente=?, telefone_cliente=?, cep_cliente=?, rua_cliente=?, numero_cliente=? 
        WHERE id_cliente=?
        '''
        data = (nome_cliente, telefone_cliente, cep_cliente, rua_cliente, numero_cliente, id_cliente)
        self.db.execute_query_no_return(query, data)

    
    def DeletarCliente(self, id_cliente):
        query = 'DELETE FROM cliente WHERE id_cliente=?'
        data = (id_cliente,)
        self.db.execute_query_no_return(query, data)

    
    def AtivarInativarCliente(self, tipo, id_cliente):
        query = 'UPDATE cliente SET ativo_cliente=? WHERE id_cliente=?'
        data = (tipo, id_cliente)
        self.db.execute_query_no_return(query, data)

    
    def ValidarCliente(self, id_cliente):
        query = 'SELECT ativo_cliente FROM cliente WHERE id_cliente=?'
        data = (id_cliente,)
        return self.db.execute_query(query, data)

    
    
        