from database.database import Database
class CategoriaController:
    def __init__(self):
        self.db = Database()    
    
    def create_table(self):
        sql = '''
        CREATE TABLE IF NOT EXISTS categoria (
        id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
        descricao_categoria TEXT NOT NULL,
        ativo_categoria BOOLEAN
         )
        '''
        self.db.create_table(sql)
      
    def ListarCategoria(self,tipo):
        query = 'SELECT * FROM categoria where ativo_categoria=?'
        data = (tipo,)
        return self.db.execute_query(query,data)
    
    def CadastrarCategoria(self, nome ):
        query = 'INSERT INTO categoria (descricao_categoria,ativo_categoria) VALUES (?, ?)'
        data = ( nome, True)
        self.db.execute_query_no_return(query, data)
    
    def EditarCategoria(self, nome, id):    
        query = 'UPDATE categoria SET descricao_categoria=? WHERE id_categoria=?'
        data = (nome, id)
        self.db.execute_query_no_return(query, data)
    
    def DeletarCategoria(self, id):    
        query = 'DELETE FROM categoria WHERE id_categoria=?'
        data = (id,)
        self.db.execute_query_no_return(query, data)
    
    def AtivarInativarCategoria(self,tipo,id):
        query = 'UPDATE categoria SET ativo_categoria=? WHERE id_categoria=?'
        data = (tipo, id)
        self.db.execute_query_no_return(query, data)
  
    def ValidarCategoria(self,id):
        query = 'SELECT ativo_categoria FROM categoria WHERE id_categoria=?'
        data = (id,)
        return self.db.execute_query(query, data)
    
    
        