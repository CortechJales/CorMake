from PyQt5.QtWidgets import QMainWindow, QAction, QStackedWidget, QHBoxLayout, QWidget, QSpacerItem, QPushButton, QSizePolicy, QLabel, QApplication
from PyQt5.QtGui import QIcon, QFont, QPixmap
from cliente.cliente_ui import ClienteUI
from categoria.categoria_ui import CategoriaUI
from marca.marca_ui import MarcaUI
from database.cadastro_usuário import CadastroUsuario
from login.login_window import LoginWindow
import sys
import os

class MainWindow(QMainWindow):
    def __init__(self, user_type=None):
        super().__init__()

        self.setWindowTitle("Sistema de Gerenciamento")
        self.resize(1200, 800)
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))
        pasta_imagens = os.path.join(diretorio_atual, 'img')
        caminho_imagem = os.path.join(pasta_imagens, 'cormake.png')
        self.setWindowIcon(QIcon(caminho_imagem))

        self.central_widget = QStackedWidget()
        self.setCentralWidget(self.central_widget)

        self.cliente_ui = ClienteUI(user_type)
        self.categoria_ui = CategoriaUI(user_type)
        self.marca_ui =  MarcaUI(user_type)
        self.cadastro_ui = CadastroUsuario()

        self.central_widget.addWidget(self.cliente_ui)
        self.central_widget.addWidget(self.marca_ui)
        self.central_widget.addWidget(self.cadastro_ui)

        self.create_toolbar(user_type)
        self.center_on_screen()

    def center_on_screen(self):
        screen_geometry = QApplication.primaryScreen().geometry()
        window_geometry = self.frameGeometry()
        window_geometry.moveCenter(screen_geometry.center())
        self.move(window_geometry.topLeft())

    def create_toolbar(self, user_type):
        toolbar = self.addToolBar("Toolbar")

        # Adicionando logo à toolbar
        logo_label = QLabel(self)
        diretorio_atual = os.path.dirname(os.path.abspath(__file__))
        pasta_imagens = os.path.join(diretorio_atual, 'img')
        caminho_imagem = os.path.join(pasta_imagens, 'bunner3.png')
        pixmap = QPixmap(caminho_imagem)
        scaled_pixmap = pixmap.scaled(160,80)  # Ajustar o tamanho conforme necessário
        logo_label.setPixmap(scaled_pixmap)
        toolbar.addWidget(logo_label)

        # Definindo ação para cada botão da toolbar
        cliente_action = QAction("Clientes", self)
        cliente_action.triggered.connect(lambda: self.change_page(self.cliente_ui))
       
        categoria_action = QAction("Categorias", self)
        categoria_action.triggered.connect(lambda: self.change_page(self.categoria_ui))
        
        marca_action = QAction("Marcas", self)
        marca_action.triggered.connect(lambda: self.change_page(self.marca_ui))



        
       

        if user_type == 'adm':
            usuario_action = QAction("Usuários", self)
            usuario_action.triggered.connect(lambda: self.change_page(self.cadastro_ui))

        actions = [cliente_action, categoria_action, marca_action ]
        if user_type == 'adm':
            actions.append(usuario_action)

        button_style = """
           QPushButton{
            background-color: #f5026d;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 10px;
            margin-left: 10px;
            margin-top: 5px;
            }

            QPushButton:hover {
                background-color: #ff93c1;
            }
        """

        for action in actions:
            action_button = QPushButton(action.text(), self)
            action_button.setStyleSheet(button_style)
            action_button.clicked.connect(action.trigger)
            toolbar.addWidget(action_button)

        # Adicionar botão de deslogar à direita
        layout = QHBoxLayout()
        spacer = QSpacerItem(20, 40, QSizePolicy.Expanding, QSizePolicy.Minimum)
        layout.addItem(spacer)

        btn_logout = QPushButton("Deslogar")
        btn_logout.setMinimumWidth(100)
        btn_logout.clicked.connect(self.show_login_dialog)
        btn_logout.setStyleSheet("""
             QPushButton{
            background-color: #be0d32;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 10px;
            margin-left: 10px;
            margin-top: 5px;
            }

            QPushButton:hover {
                background-color: #ff93c1;
            }
        """)
        btn_logout.setFont(QFont("Arial", 10))

        layout.addWidget(btn_logout)

        widget = QWidget()
        widget.setLayout(layout)

        toolbar.addWidget(widget)

    def change_page(self, page):
        # Altera para a página especificada e chama filter_active() se for uma UI válida
        self.central_widget.setCurrentWidget(page)
        if hasattr(page, 'filter_active') and callable(getattr(page, 'filter_active')):
            page.filter_active()

    def show_login_dialog(self):
        self.hide()
        self.login_window = LoginWindow()
        self.login_window.show()
        if self.login_window.exec_() == LoginWindow.Accepted:
            user_type = self.login_window.user_type
            self.handle_login_success(user_type)

    def handle_login_success(self, user_type):
        self.user_type = user_type
        self.show_main_window(user_type)

    def show_main_window(self, user_type):
        self.login_window.close()
        self.main_window = MainWindow(user_type)
        self.main_window.show()

    def close_application(self):
        self.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())
